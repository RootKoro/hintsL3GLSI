Vous pouvez retrouver la base de données SAKILA à l'url suivante : 
https://downloads.mysql.com/docs/sakila-db.zip

L'explication du modèle de données est à l'url suivante : 
https://personal.ntu.edu.sg/ehchua/programming/sql/SampleDatabases.html

Pour d'autres sur la base , prière de regarder l'url suivante : 
https://dev.mysql.com/doc/sakila/en/
