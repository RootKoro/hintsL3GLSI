<?php
    $user = 'tp_user';
    $pass = 'passer';
    $host = 'mysql:host=localhost;dbname=tp_php';
?>