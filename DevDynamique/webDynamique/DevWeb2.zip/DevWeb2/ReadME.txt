----------------------------------------------------------
Pour le bon fonctionnement de ce projet, veuillez modifier le fichier php/.conf.php
Ne surtout pas oublier d'importer la base de donnees dans BD/db.sql